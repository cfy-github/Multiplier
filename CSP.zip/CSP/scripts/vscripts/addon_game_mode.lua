-- Your game mode should be instantiated here
MultiplierGameMode:InitGameMode()